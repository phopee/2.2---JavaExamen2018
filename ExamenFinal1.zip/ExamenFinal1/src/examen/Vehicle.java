package examen;


/* Profesori: Cosmin CARTAS, Ph. D. Candidate & Razvan MARALES, Ph. D. Candidate
 * 
 * Examenul se da la calculator
 * 
 * Deja din timpul examenului vei sti la ce nota ai ajuns:
 * codul scris in timpul examenului este testat (JUnit)
 * si astfel ai deja feedback daca ceea ce ai scris este corect:
 * - daca este incorect, ai chiar si un hint care te ajuta sa corectezi codul
 */



/*  
 *  Nota 2
 *  Create the interface Vehicle with the method getDetails() returning String, must be inserted
 *  
 * */
public interface Vehicle {
	public String getDetails();
}
